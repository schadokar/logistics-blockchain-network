# Logistics Network   

## Participants

Seller -- Create shipment  
Buyer  -- Receive Shipment
Logistics  -- Transport Shipment from seller to buyer

## Asset
Shipment

## Transaction
TransferOwnership  -- transfer the ownership from one participant to other participant
ShipmentTempUpdate  -- update temperature readings of the shipment
SetupDemo -- Initialize all the participants and shipments
